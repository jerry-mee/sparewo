import 'package:flutter/material.dart';
import 'package:sparewo/common/widgets/custombutton.dart';
import 'package:sparewo/common/widgets/menu_bar.dart';
import 'package:sparewo/utilis/constants.dart';

import '../../common/widgets/appstore_links_widget.dart';
import '../../common/widgets/blog_widget.dart';
import '../../common/widgets/bottom_information_panel.dart';
import '../../common/widgets/cars_listing.dart';
import '../../common/widgets/search_card.dart';
import '../../common/widgets/special_offer_banner.dart';
import '../../common/widgets/product_tiles.dart';
import '../../common/widgets/searchbycatorgies.dart';
import 'package:carousel_indicator/carousel_indicator.dart';

class HomePage extends StatelessWidget {
  HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          SpecialOfferBanner(),
          MenuBarWidget(),
          SearchCard(),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 100, vertical: 10),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Container(
                width: 500,
                child: Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(20))),
                  child: Padding(
                    padding: const EdgeInsets.all(40.0),
                    child: Column(
                      children: [
                        Text(
                          'Select your Car to find Matching Parts',
                          textAlign: TextAlign.start,
                          style: TextConstant
                              .homeProductButtonSelectedTitleTextStyle,
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        CarSearchDropDownButton(Text: 'Car Brand'),
                        SizedBox(
                          height: 10,
                        ),
                        CarSearchDropDownButton(Text: 'Car Model'),
                        SizedBox(
                          height: 10,
                        ),
                        CarSearchDropDownButton(Text: 'Car Name'),
                        SizedBox(
                          height: 10,
                        ),
                        CarSearchDropDownButton(Text: 'Car Number'),
                        SizedBox(
                          height: 10,
                        ),
                        CustomButton(text: 'Search', onPressed: () {})
                      ],
                    ),
                  ),
                ),
              ),
              SizedBox(
                width: 20,
              ),
              Container(
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(20))),
                height: 400,
                child: Image.asset(
                  'assets/images/banner.jpg',
                  fit: BoxFit.cover,
                ),
              )
            ]),
          ),
          SearchByCategory(),
          ProducatTiles(),
          CarsListings(),
          BlogWidget(),
          AppStoreLinksWidget(),
          BottomInformationPanel()
        ],
      ),
    );
  }
}

class CarSearchDropDownButton extends StatelessWidget {
  const CarSearchDropDownButton({
    required this.Text,
    super.key,
  });
  final String Text;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 40,
      child: TextField(
        onChanged: (a) {},
        decoration: InputDecoration(
          suffixIcon: Container(
            padding: EdgeInsets.all(3),
            child: IconButton(
                onPressed: () {}, icon: Icon(Icons.arrow_downward_outlined)),
          ),
          hintText: Text,
          hintStyle: TextStyle(color: Colors.grey),
          focusedBorder: const OutlineInputBorder(
              borderSide:
                  BorderSide(color: ColorConstant.kPrimerColor, width: 2)),
          border: const OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(10)),
              borderSide: BorderSide(width: 2)),
        ),
      ),
    );
  }
}
