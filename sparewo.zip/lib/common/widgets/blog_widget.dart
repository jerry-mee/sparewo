import 'package:flutter/material.dart';

import '../../utilis/constants.dart';

class BlogWidget extends StatelessWidget {
  const BlogWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
            height: 1000,
            color: ColorConstant.blueDarker,
            child: Column(
              children: [
                Container(
                  height: 120,
                  color: Colors.white,
                ),
              ],
            )),
        Container(
          alignment: Alignment.center,
          height: 1000,
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 20),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Padding(
              padding: const EdgeInsets.only(left: 200.0),
              child: Row(
                children: [
                  Column(
                    children: [
                      GestureDetector(
                        onTap: () {},
                        child: const ActionStack(
                          label: "Get Quote",
                          imageUrl: 'assets/images/quote.png',
                        ),
                      ),
                      const SizedBox(height: 20),
                      GestureDetector(
                        onTap: () {},
                        child: const ActionStack(
                          label: "Request\nService",
                          imageUrl: 'assets/images/service.png',
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(width: 20),
                  Stack(
                    alignment: Alignment.bottomLeft,
                    children: [
                      SizedBox(
                        height: 400,
                        width: 400,
                        child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.asset("assets/images/person.jpg",
                                fit: BoxFit.fill)),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 20.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'Become a\nMerchant',
                              style: TextStyle(
                                  fontSize: 50,
                                  fontWeight: FontWeight.w900,
                                  color: Colors.white),
                            ),
                            SizedBox(height: 10),
                            Text(
                              "Reach even more customers\nby selling your products\nwith us.",
                              textScaleFactor: 1.2,
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.white),
                            ),
                            SizedBox(height: 10),
                            Text(
                              "Join Now",
                              style: TextStyle(
                                  decorationThickness: 2,
                                  decoration: TextDecoration.underline,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w900,
                                  color: Colors.white),
                            ),
                            SizedBox(height: 10),
                          ],
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
            const SizedBox(height: 20),
            const SOSWidget(),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 200.0),
              child: Text(
                'FROM OUR BLOG',
                style: TextConstant.bottomHeaderTextStyle
                    .copyWith(fontWeight: FontWeight.w900),
              ),
            ),
            const SizedBox(height: 20),
            const BlogCard()
          ]),
        ),
      ],
    );
  }
}

class ActionStack extends StatelessWidget {
  const ActionStack({Key? key, required this.imageUrl, required this.label})
      : super(key: key);
  final String imageUrl;
  final String label;
  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.centerLeft,
      children: [
        SizedBox(
            height: 190,
            width: 400,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.asset(imageUrl, fit: BoxFit.fill),
            )),
        Padding(
          padding: const EdgeInsets.only(left: 20.0),
          child: Text(
            label,
            style: const TextStyle(
                fontSize: 30, fontWeight: FontWeight.w900, color: Colors.white),
          ),
        )
      ],
    );
  }
}

class SOSWidget extends StatelessWidget {
  const SOSWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
        child: Container(
            height: 120,
            width: double.infinity,
            padding: const EdgeInsets.only(left: 200, right: 200),
            child: Image.asset("assets/images/sos.jpg", fit: BoxFit.fill)));
  }
}

class BlogCard extends StatelessWidget {
  const BlogCard({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
        child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 250.0),
      child: ListView.builder(
        physics: const NeverScrollableScrollPhysics(),
        scrollDirection: Axis.horizontal,
        itemBuilder: (ctx, index) => Container(
          alignment: Alignment.center,
          width: 250,
          padding: const EdgeInsets.only(right: 40),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
            Container(
              height: 200,
              decoration:
                  BoxDecoration(borderRadius: BorderRadius.circular(10)),
              width: double.infinity,
              child: Image.asset("assets/images/logo.png"),
            ),
            const SizedBox(height: 10),
            Text(
              "How to professionally clean your engine",
              style: TextConstant.bottomHeaderTextStyle
                  .copyWith(fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 10),
            const Text(
              "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec non est sed magna dapibus commodo luctus quis est.",
              style: TextConstant.bottomLabelsTextStyle,
            ),
            const SizedBox(height: 10),
            Row(
              children: const [
                CircleAvatar(
                  radius: 10,
                  backgroundColor: ColorConstant.yellow,
                  child: Icon(
                    Icons.arrow_forward_ios_sharp,
                    color: Colors.white,
                    size: 10,
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                Text(
                  "Read More",
                  style: TextConstant.bottomHeaderTextStyle,
                )
              ],
            )
          ]),
        ),
        itemCount: 3,
      ),
    ));
  }
}
