import 'package:flutter/material.dart';

class AppStoreLinksWidget extends StatelessWidget {
  const AppStoreLinksWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      width: double.infinity,
      decoration: const BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: [Color(0xfffabb0a), Color(0xfff08335)])),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Text("Get faster Service\nvia our app.",
            style: TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.w900,
                color: Colors.white)),
        const SizedBox(width: 40),
        SizedBox(width: 100, child: Image.asset("assets/images/appstore.png")),
        const SizedBox(width: 10),
        SizedBox(
            width: 100, child: Image.asset("assets/images/google_store.png")),
      ]),
    );
  }
}
