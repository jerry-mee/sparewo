import 'package:flutter/material.dart';

class CarsListings extends StatelessWidget {
  const CarsListings({super.key});

  @override
  Widget build(BuildContext context) {
    List<String> carList = [
      "jeep",
      "nissan",
      'lexus',
      "sib",
      "toyota",
      "mit",
      "honda",
      "bmw"
    ];
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.only(left: 200),
      height: 200,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemBuilder: (ctx, index) => Padding(
          padding: const EdgeInsets.all(10.0),
          child: SizedBox(
            height: 80,
            width: 80,
            // ignore: prefer_interpolation_to_compose_strings
            child: Image.asset("assets/images/" + carList[index] + '.png'),
          ),
        ),
        itemCount: 8,
      ),
    );
  }
}
