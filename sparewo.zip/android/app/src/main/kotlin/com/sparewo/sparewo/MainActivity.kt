package com.sparewo.sparewo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
